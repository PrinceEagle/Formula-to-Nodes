# Formula to Nodes 3.2.0 — Live Viewer, Houdini-friendly

Shaped by usability sessions with three Houdini artists (FX TD, environment/modeling,
motion design) on Blender 5.3.

## Live Viewer
- A node card drawn in the Geometry Node Editor while you write: outputs, inputs with defaults
  and panels, node count, or the error with its line. Recompiles only when the text changes.
- Live values: min / avg / max of the attributes the script writes on the active object
  (mesh, points, curves and instances), element counts, NaN/inf warnings.
- Sidebar toggles: Viewer, Values, corner.

## Friendlier editing
- **Open in Text Editor** (split next to the nodes) and **Ctrl+Enter** in the Text Editor builds.
- Building inside a Formula group updates it in place (no stray new group).
- Asks before a rebuild that would replace the selected group with a different script, overwrite
  hand edits to its nodes, or cut links to sockets that go away.
- Every replaced script is kept in a *Formula Recovery* text datablock.
- **Save as Preset** / *Recipes › My Presets* (stored in your Blender config, with a backup).

## Houdini habits
- Unknown unprefixed attributes are floats (VEX rule); `@age @life @dead @force @accel @drag @pstate`
  and friends have their POP types. `@TimeInc` = deltatime in a sim, seconds per frame outside.
- Groups as bool attributes: `@group_name`, `inpointgroup / inprimgroup / setpointgroup / setprimgroup`.
- `@curveu` → `@curveparam`; reading `@class` (or any attribute nothing writes) explains what it reads.
- `$F`, `$T`… give an HScript hint; `{0, -9.8, 0}` notes Blender is Z-up; per-point `@density` notes
  `runover(voxel)`; `ch()` without a default notes it starts at 0.
- Unknown statement calls (`polybevel()`) say "unknown function" with the Blender equivalent.
- `instance()` without `p@orient` aligns +Z to `@N` and +Y to `v@up` (Copy to Points).
- Easing: `easein easeout easeinout easeoutback easeoutelastic easeoutbounce`.
- `sweep(chobj("profile") [, scale])` sweeps a profile curve. `radians()/degrees()` take vectors.

## Presets (91 recipes, new "From Houdini" column)
- From Houdini: Attribute Transfer, Group Expression, PolyExtrude a group, Connectivity, Sweep a
  profile curve, Mountain, Peak, Measure, Attribute Noise, Copy to Points prep, Point Relax.
- POP Source + forces, Age to colour & size, Stagger in, Random effector, Step & cascade,
  Radial cloner.
- Recipe search ranks partial matches, so SOP names find the closest tools.
- Fixed: smoke recipes passed time as curl-noise detail; particles now use `@v` (Blender velocity).

## Claude / MCP
- `formula_set_parameters`: object/collection/material pickers by name, `"Panel/name"` paths,
  ramp presets, and partial success.
- `formula_inspect`: instances, volume grids, min/mean/max, `frames=[…]`, `elements=[…]`,
  empty object inputs flagged.
- Language guide and checks use the running Blender's version (5.3 features no longer reported
  missing); parameters listed with panel paths and ramps.

# Formula to Nodes 3.1.0 — Blender 5.3

Volumes, real fluid solvers and the new Blender 5.3 nodes. Still works on 5.2 (features that need
5.3 say so, and the solvers fall back to iterating).

## Volumes (OpenVDB grids)
- **`runover(voxel) { }`** — a Volume Wrangle: every `@name` is a grid, `@P` the voxel centre,
  `@ix @iy @iz` its index. All writes in a block go through **one** Field to Grid node, so shared
  maths runs once per voxel.
- **`volumebounds(min, max, voxelsize)`** sets the voxel box (cube voxels, rounded up).
- Whole-grid operations: `volumeadvect` (MacCormack, BFECC, RK3/4, semi-Lagrangian),
  **`volumeproject`** (divergence-free velocity with Blender 5.3's **Poisson Solver** — one node
  instead of hundreds of Jacobi iterations; 5.2 falls back to Jacobi), `volumesolve` (∇²u = f),
  `volumeblur`, `volumecurl`, `volumedivergence`, `volumegrad`, `volumeremove`.
- Conversions: **`rasterize()`** (points → grids, 5.3 Rasterize Points, colour too),
  `volumefrompoints` (metaballs), `volumefrommesh` (SDF or fog), `volumetomesh`,
  `sdfsmooth`, `sdfoffset`, `sdffillet`, `sdfboolean`.
- `keep("volume")` (or mesh/points/curves/instances) drops the other geometry types.

## Research papers, implemented as recipes (Blender 5.3)
- **Immersed bubbles** — Wretborn, Stomakhin & Batty (Wētā FX / Waterloo), *A unified multi-scale
  method for simulating immersed bubbles*, Eurographics 2025. Massful air particles two-way coupled
  to the water grid: P2G of the air fraction and drag terms in one Rasterize Points pass, the φ ≤ 1
  clamp (Eq. 31), Eq. 36 drag solved in closed form (exact at any time step, 1:1000 density ratio),
  CSF surface tension, mixture projection with the Poisson Solver, MacCormack water, and the
  r_surfacing merge surface. A single bubble's terminal slip matches the drag law within 1%.
- **Particle flow maps** — Zhou et al., *Eulerian-Lagrangian Fluid Simulation on Particle Flow
  Maps*, ACM TOG / SIGGRAPH 2024. Particles carry the flow-map Jacobian T and the impulse m = Tᵀm₀,
  affine P2G (Eq. 17) in one Rasterize Points pass, Cayley update of T (scaled and squared),
  per-frame plus adaptive per-particle reinitialisation. Smoke density stays on the particles.
- New functions: `volumejacobian()`, `matrix3()`, `matcol()`, `matmul()`, `mulvec()`;
  `rasterize(..., 0, kernel, "average")` aligned to `volumebounds()` and batched into one node;
  `volumesample(..., "linear"|"cubic"|"nearest")` (cubic = 5.3 Tricubic).

## Blender 5.3 nodes
- Array literals use **Combine List** (one node instead of Field to List + Index Switch).
- `v[i]` / `getcomp()` with a variable index use **Get Vector Component**.
- `sweep(radius, resolution, 1)` — Curve to Mesh's **Miter Scale** keeps tubes even at corners.
- `realize(1)` — Realize Instances' **Preserve Normals** for mirrored instances.
- Convert Nodes to Script understands all of the above, plus `points()`, `grid()` and grid sampling.

## Recipes (60 in 12 categories)
- New categories **Smoke & Fire**, **Liquids**, **Volumes**: smoke plume (buoyancy, curl-noise
  turbulence, vorticity confinement), fire (fuel → heat + soot, blackbody), smoke ring (vortex ring
  from a single push), smoke from an animated object, shallow-water dam break (Lax–Wendroff, CFL
  adaptive substeps), bubbles (rise, wobble, merge, pop), cloud from any mesh, spiral galaxy
  (5.3 rasterize), lava lamp metaballs. Wave pool moved to Liquids.
- Recipes that need a newer Blender are greyed out in the menu.
- New colour ramp presets: `ocean`, `smoke`.

## Language
- `rand(@ptnum + 0.37)` now gives a different stream from `rand(@ptnum)` (like VEX); integer
  seeds are unchanged.

## AI / MCP
- The AI prompt documents volumes and a **performance** section (prefer built-in solvers, write
  each grid once, CFL-derived time steps), so generated scripts are built the fast way.

# Formula to Nodes 3.0.0

A much bigger language, closer to Houdini VEX, plus recipes and nodes → script.

## Language
- **Run over any domain**: `#runover prim` (or vertex, edge, curve, instance, detail) and
  `runover(prim) { ... }` blocks. Detail attributes (`runover(detail)`, `detail()`,
  `setdetailattrib()`) are stored in geometry bundles.
- **Types**: rotations (`vector4`/`p@`), 4x4 matrices (`matrix`/`4@`), colours (`c@`), 2D UVs (`u@`),
  strings (`s@` text attributes need Blender 5.3), objects/collections/materials/images/sounds as parameters.
- **Arrays** (Blender 5.2 lists): `float vals[] = {1, 2, 3};`, indexing, `len`, `append`, `insert`,
  `removeindex`, `resize`, `sort`, `sum`, `min`/`max`/`avg`, `find`, `foreach (float v; vals)`.
- **Functions** with typed parameters (passed by reference, like VEX), `return`, overloads.
- **Loops**: C-style `for`, `foreach`, `repeat(n)`; short fixed loops unroll, others become repeat zones.
- **Preprocessor**: `#define`, `#include` (bundled `falloff.h`, `sdf.h`, `shaping.h`, `color.h`,
  `noise.h`, or your own text blocks), `#pragma`.
- **Geometry operations**: scatter, instance, realize, subdivide, subdivsurf, triangulate, dualmesh,
  convexhull, fuse, extrude, bevel, resample, sweep, tocurves, topoints, points, grid, join, transform,
  setmaterial, shadesmooth, flipfaces, sortpoints, removepoint/removeprim, addpoint.
- **185 new function names** (99 → 284): lookups (`point`, `prim`, `nearpoint`, `xyzdist`, `primuv`, `intersect`,
  ray casts, `volumesample`, `texture`), topology (`neighbour`, `primpoint`, ...), aggregates
  (`sumof`, `avgof`, `minof`, ... with an optional group or domain), rotations and matrices
  (`quaternion`, `slerp`, `dihedral`, `lookat`, `maketransform`, ...), colour, text (`sprintf`,
  `printf`/`warning`/`error` shown as node warnings), noise (`curlnoise`, `flownoise`, `gabor`, worley).
- **Ramps**: `chramp("name", x, "preset")` / `colorramp(...)` with presets; edited shapes survive rebuilds.
- **Parameters** get panels (`chf("Folder/name")`), ranges and tooltips (`min=`, `max=`, `tip=`).

## Recipes
51 ready-made scripts in 9 categories (masks, deformers, scatter & instance, growth & simulation,
effectors, colour, curves, modeling, utility): Script panel › **Recipes**, or `formula_list_recipes` over MCP.

## Nodes → script
**Convert Nodes to Script** turns any Geometry Nodes group into a script (like VOPs → wrangle).
Anything without an equivalent is listed in notes, never silently changed.

## Blender versions
Capability checks tell you which features your Blender has (string attributes need 5.3); the AI
prompt and the function reference only show what the running Blender supports.

## AI / MCP
- Default model `claude-sonnet-5-5`, with server-side fallback to another model when it's overloaded,
  clearer refusals, 16k output tokens and a 180 s timeout.
- New MCP tools: `formula_list_recipes`, `formula_get_recipe`, `formula_capabilities`, `formula_decompile`.

# Formula to Nodes 2.1.0

## New: Claude Desktop / Claude Code via MCP
Works together with Blender Lab's **MCP** add-on (the bridge inside Blender).
- Sidebar › Formula › **Claude Desktop (MCP)** › *Connect Claude Desktop* adds
  `formula-to-nodes` to Claude's config (macOS, Windows incl. Microsoft Store).
  Existing servers are kept and a `.bak` backup is written. Restart Claude.
- Runs on Blender's own bundled Python: nothing else to install.
- Tools Claude gets: language guide, check script, build (and apply to an
  object), inspect evaluated attribute values, set parameters, list groups,
  get a group's source, scene overview.
- *Copy JSON* / *Claude Code* buttons for other MCP clients.

# Formula to Nodes 2.0.0

## Fixed (all verified by evaluating geometry in Blender 5.2)
- Vector math in nested expressions no longer collapses to a scalar: `(a + b) * 0.5`
- Unary minus, `abs()`, `floor()` etc. on vectors are now per-component
- `v ** 2`, `%` and `//` no longer silently turn into `+`
- `log(x)` is the natural log (it used base 0.5)
- Trailing `//` comments no longer create fake sliders or syntax errors
- `refract()` IOR went into the wrong socket
- `curveparam` crashed in 5.2 (Curve Parameter node was renamed)
- Locals now keep their value after later writes, like VEX
- Locals declared in simulate/foreach blocks can't leak out into invalid links
- Constants on implicit-input sockets (Set Position, Noise, Random ID…) were ignored
- Vector values stored into float attributes are now an error instead of an average
- "Replace Active" could delete hand-made node groups

## New
- if / else if / else, ternary `? :`, comparisons, `&& || !`
- `repeat(n) { }` zones, nested zones, `return` for field outputs
- Vector literals `{x, y, z}`, VEX aliases `@P @N @ptnum @pscale @Time …`
- `chf/chi/chv/chb` parameters with defaults and min/max
- Writes to `@N` (custom normals), `@id`, `@pscale`, `f@tilt`
- 99 functions incl. fit01, efit, smooth, snoise, rand, relbbox, npoints
- Smaller trees: constants inlined, repeated sub-expressions shared
- Automatic left-to-right layout that respects zones
- Updating a group keeps its name, links and modifier values
- Edit Selected Group loads a group's source back into the panel
- Check button, line-numbered errors, error line highlighted
- Examples menu
- AI Assist: Claude, OpenAI, Ollama or any OpenAI-compatible server;
  every reply is compiled and errors are sent back for a fix
- Copy Prompt for Any Chatbot (no API key needed)
